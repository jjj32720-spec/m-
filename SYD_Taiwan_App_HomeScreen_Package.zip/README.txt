SYD’s Taiwan Grand Traverse App 2026

請把以下檔案放在網站同一層：
- index.html
- manifest.webmanifest
- apple-touch-icon.png
- icon-192.png
- icon-512.png

iPhone 加到主畫面：
1. 用 Safari 開啟網站
2. 點「分享」
3. 選「加入主畫面」
4. 確認名稱後加入

注意：
若網站另外使用 1.PNG～10.PNG 與 MP3，原本那些檔案也要繼續放在同一網站路徑。
